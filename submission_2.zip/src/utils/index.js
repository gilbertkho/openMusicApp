const mapDBToModel = ({
    id, title, performer,
}) => ({
    id,
    title,
    performer    
});

module.exports = { mapDBToModel };